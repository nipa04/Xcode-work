//: Playground - noun: a place where people can play

import UIKit

var array = ["a","b","c","d"]
for index in 0..<array.count/2 {
    let leftIndex = index
    let rightIndex = ((array.count) - leftIndex) - 1
    print("\(leftIndex) and \(rightIndex)")
    let temp = array[leftIndex]
    array[leftIndex] = array[rightIndex]
    array[rightIndex] = temp
}
print(array)



