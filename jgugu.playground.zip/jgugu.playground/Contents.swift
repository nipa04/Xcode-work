//: Playground - noun: a place where people can play

import UIKit

var array = [1,2,3,4,5,3,2]
var array2 = [Int]()

for index in 0..<array.count {
    for innerIndex in (index + 1)..<array.count {
        if array[innerIndex] == array[index]{
            print("Duplicate numbers are : \(array[index])")
            array2.append(array[index])
        }
    }
}
print(array2)
array.remove(at: 5)
array.remove(at: 5)
print (array)

//let p = Array(Set(array).sorted())
//print(p)
