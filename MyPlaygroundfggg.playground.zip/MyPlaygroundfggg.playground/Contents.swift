//: Playground - noun: a place where people can play

import UIKit

var numberOfTerms = 0
var pattern = 1
while numberOfTerms < 4 {
    numberOfTerms += 1
    var numberOfPattern = 0
    while numberOfPattern <= numberOfTerms {
        pattern += 1
        print ("\(pattern)")
    }
}
