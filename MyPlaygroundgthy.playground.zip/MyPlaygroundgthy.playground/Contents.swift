//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//
//for number in 1...10 {
//    var multi = 0
//    for number2 in 1...8 {
//        multi = number * number2
//         print ("\(number) * \(number2) = \(multi)")
//    }
//}

var numberOfterm = 0
var multi = 0
while numberOfterm < 10 {
    numberOfterm += 1
    for number in 1...8 {
        multi = numberOfterm * number
        print ("\(numberOfterm) * \(number) = \(multi)")
    }
}

