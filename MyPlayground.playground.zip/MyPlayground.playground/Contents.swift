//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
var a:Int = 1
var b = 3
var e :Float = 2.8
var v:Float = 3.8
str = "2"
print (str)

print (a+b)
print (a-b)
print (a*b)

let c = 2
print (a+c)
print (c%a)
var happy = " hello"
print(happy)
 happy="helllo to"
a=4
print (a+b)
for index in 1...5 {
    var sum = 0
    sum += index
    print (sum)
}
for index in 1...100 {
    if ((index % 2) == 1) {
        print (index)
    }
}


