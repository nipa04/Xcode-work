//: Playground - noun: a place where people can play

import UIKit

class electricityBill {
    var id : Int!
    var name: String!
    var unit : Int!
  
    func calculateCharge(arg unit: CGFloat) -> CGFloat {
        var charge : CGFloat!
       
        if (unit <= 199) {
            charge = (unit * 1.20)
            print ("The charge to pay for unit is : \(charge)")
        }
        else if (unit <= 399) {
            charge = (unit * 1.50)
            print ("The charge to pay for unit is : \(charge)")
            
        }
        else if (unit <= 599) {
            charge = (unit * 1.80)
            print ("The charge to pay for unit is : \(charge)")
            
        }
        else if (unit >= 600) {
            charge = (unit * 2.00)
            print("The charge to pay for unit is : \(charge)")
            
        }
        return charge
    }
    
    func calculateTotalBill (arg charge : CGFloat) -> String{
        var surCharge : CGFloat!
        var totalCharge : CGFloat!

        if charge > 400 {
            surCharge = charge * 0.15
            print ("After adding surcharge the bill is: \(surCharge)")
            totalCharge = charge + surCharge
            print ("The net amount to pay is : \(totalCharge)")
        }
        else if charge < 100 {
            print ("not applicable")
        }
        return ("\(totalCharge)")
    }
}

let r = electricityBill()
r.id = 1009
print(r.id)
r.name = "James"
print(r.name)
r.unit = 800
r.calculateCharge(arg: 800)
r.calculateTotalBill(arg: 1600)
