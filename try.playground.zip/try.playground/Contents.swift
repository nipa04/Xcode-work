//: Playground - noun: a place where people can play

import UIKit

//var str = "welcome"
//var char = Array(str)
//str.count
//for index in 0..<char.count/2 {
//    let leftIndex = index
//    let rightIndex = (char.count - leftIndex) - 1
//    let temp = char[leftIndex]
//    char[leftIndex] = char[rightIndex]
//    char[rightIndex] = temp
//}
//
//print(char)

var array = [1,2,3,4,5,6,8,9,10]
let n = (array.count) + 1
var sum = 0
for item in array {
    sum += item
}
print(sum)
var sum2 = 0
sum2 = Int(ceil(CGFloat(n*(n+1))/CGFloat(2.0)))
var s = (sum - sum2)
print(s)

if s == 0 {
    print("There is no missing number")
}
else if (s != 0) {
    print("There is a missing number")
}

