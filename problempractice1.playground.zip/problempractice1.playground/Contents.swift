//: Playground - noun: a place where people can play

import UIKit

var number1:Int = 5
var number2: Int = 5

if (number1 > number2) {
    print ("number1 is greater than number2")
}
if (number1 < number2)  {
    print ("number1 is less than number2")
}
if (number1 == number2 ){
    print ("number1 is equal to number2")
}
