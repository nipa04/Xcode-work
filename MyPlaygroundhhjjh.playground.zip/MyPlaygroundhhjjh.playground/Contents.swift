//: Playground - noun: a place where people can play

import UIKit

var numberOfTerms = 0
while numberOfTerms < 4 {
    var numberOfTimes = 0
    var pattern = 0
    while numberOfTimes < numberOfTerms {
        pattern += 2
        print(pattern)
        numberOfTimes += 1
    }
    numberOfTerms += 1
}

//var array = ["a","b","c","d"]
//for index in 0..<array.count/2 {
//    let leftIndex = index
//    let rightIndex = ((array.count) - leftIndex) - 1
//    print("\(leftIndex) and \(rightIndex)")
//    var temp = array[leftIndex]
//    array[leftIndex] = array[rightIndex]
//    array[rightIndex] = temp
//}
//print(array)
//

//var str = "hello"
//var character = Array(str)
//character.count
//for index in 0..<character.count/2 {
//    let leftIndex = index
//    let rightIndex = ((character.count) - leftIndex) - 1
//    var temp = character[leftIndex]
//    character[leftIndex] = character[rightIndex]
//    character[rightIndex] = temp
//}
//print(character)


//let array = [1,4,2,3,5]
//let n = array.count
//let k = 7
//var leftIndex = 0
//var rightIndex = n - 1
//while leftIndex < rightIndex {
//    let sum = array[leftIndex] + array[rightIndex]
//    if sum == k {
//        print("\(array[leftIndex]) and \(array[rightIndex])")
//        break
//    }
//    else if sum < k {
//        leftIndex += 1
//    }
//    else{
//        rightIndex -= 1
//    }
//}





