//: Playground - noun: a place where people can play

import UIKit

let array = [1,4,2,3,5]
let n = array.count
let k = 7
var leftIndex = 0
var rightIndex = n - 1
while leftIndex < rightIndex {
    let sum = array[leftIndex] + array[rightIndex]
    if sum == k {
        print("\(array[leftIndex]) and \(array[rightIndex])")
        break
    }
    else if sum < k {
        leftIndex += 1
    }
    else{
        rightIndex -= 1
    }
}
